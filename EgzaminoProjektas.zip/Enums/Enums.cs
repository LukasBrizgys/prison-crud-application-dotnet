﻿using System.ComponentModel;
using System.Reflection;

namespace EgzaminoProjektas.Enums
{
    public enum PrisonerStatus
    {
        Paleistas = 1,
        Kalintis = 2
    }
}
